Imports System.Globalization
Module Module1
  Sub Main()
  Try
	Console.Write("Zadejte x pro výpočet sin x: ")
    Dim x as decimal = cdec(Console.readline)
	Console.Write("Zadejte počet desetinných míst (max 14): ")
	dim pres as long = console.readline
	Dim presnost as decimal = cdec(10^-pres)
    Dim sin as decimal = x
	dim i as long = 4
    dim f as Ulong = 6
    dim eps as decimal
	dim n as long = x*-x
    Do
        eps=(n)/(f)
        sin+=eps
        f*=i*(i+1)
		i+=2
		n*=x*-x
    Loop Until Math.abs(eps)<presnost
	Console.writeline(sin.tostring("F" & pres, CultureInfo.CurrentCulture))
	Console.readkey()
	Catch sin as Exception
		msgbox(sin.ToString,MsgBoxStyle.Critical,"ERROR " & err.number & " - " & err.description)
	end try
  End Sub
End Module